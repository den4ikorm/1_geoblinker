# 💎 ГЕОБЛИНКЕР: ЕДИНЫЙ СТИЛЬ (NEON CYBER)
Ориентир: Скриншот Auth (Градиенты и капсулы)

## 🎨 ЦВЕТА
- Background: #050A18 (Deep Space)
- Кнопка 1: Градиент #00E5FF -> #007AFF
- Кнопка 2: Dark Glass (#1A1F2B) + White Border

## 📐 ГЕОМЕТРИЯ
- Кнопки: RoundedCornerShape(24.dp)
- Высота: 56.dp
