package org.example.geoblinker.presentation.features.auth
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text

@Composable fun LoginScreen(onLoginSuccess: () -> Unit) { Text("Вход (БЕТОН)") }
@Composable fun RegisterScreen(onBack: () -> Unit) { Text("Регистрация (БЕТОН)") }
