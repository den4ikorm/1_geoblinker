package org.example.geoblinker.presentation.features.auth

import androidx.compose.material.Text
import androidx.compose.foundation.Image
import androidx.compose.material.Text
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.material.*
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.material.Text
import androidx.compose.ui.Alignment
import androidx.compose.material.Text
import androidx.compose.ui.Modifier
import androidx.compose.material.Text
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.Text
import androidx.compose.ui.unit.dp
import androidx.compose.material.Text
import cafe.adriel.voyager.core.screen.Screen
import androidx.compose.material.Text
import org.example.geoblinker.generated.resources.*
import androidx.compose.material.Text
import org.jetbrains.compose.resources.painterResource
import androidx.compose.material.Text
import org.jetbrains.compose.resources.painterResource

class LoginScreen : Screen {
    @Composable
    override fun Content() {
        Box(modifier = Modifier.fillMaxSize()) {
            // Фон (теперь ссылаемся на XML версию из твоего списка)
            Image(
                painter = painterResource(Res.drawable.background_registration),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Логотип (есть в списке)
                Image(
                    painter = painterResource(Res.drawable.m_1),
                    contentDescription = "Logo",
                    modifier = Modifier.width(200.dp).padding(bottom = 32.dp)
                )

                var login by remember { mutableStateOf("") }
                var pass by remember { mutableStateOf("") }

                // Используем phone.xml вместо ic_login
                TextField(
                    value = login,
                    onValueChange = { login = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Логин") },
                    leadingIcon = { Icon(painterResource(Res.drawable.phone), null, modifier = Modifier.size(24.dp)) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Использу(ем) карандаш (pencil.xml) или настройки, пока нет иконки пароля
                TextField(
                    value = pass,
                    onValueChange = { pass = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Пароль") },
                    leadingIcon = { Icon(painterResource(Res.drawable.pencil), null, modifier = Modifier.size(24.dp)) }
                )

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = { /* Phase 3 */ },
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    Text("ВОЙТИ")
                }
            }
        }
    }
}
