package org.example.geoblinker.di

import org.koin.dsl.module
import org.example.geoblinker.presentation.features.auth.AuthViewModel
import org.example.geoblinker.presentation.features.devices.DevicesViewModel
import org.example.geoblinker.domain.repository.*

val appModule = module {
    single { AuthRepository() }
    single { DeviceRepository() }
    single { SessionManager() }
    factory { AuthViewModel(get(), get()) }
    factory { DevicesViewModel(get()) }
}
